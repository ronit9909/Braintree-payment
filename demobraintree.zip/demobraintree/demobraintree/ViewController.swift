//
//  ViewController.swift
//  demobraintree
//
//  Created by mac on 03/09/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import BraintreeDropIn
import Braintree

class ViewController: UIViewController {

    var addtoken : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fetchClientToken()
        // Do any additional setup after loading the view.
    }
    func fetchClientToken() {
        // TODO: Switch this URL to your own authenticated API
        let clientTokenURL = NSURL(string: "https://braintree-sample-merchant.herokuapp.com/client_token")!
        let clientTokenRequest = NSMutableURLRequest(url: clientTokenURL as URL)
        clientTokenRequest.setValue("text/plain", forHTTPHeaderField: "Accept")
        
        URLSession.shared.dataTask(with: clientTokenRequest as URLRequest) { (data, response, error) -> Void in
            // TODO: Handle errors
            let clientToken = String(data: data!, encoding: String.Encoding.utf8)
            self.addtoken = clientToken
            self.showDropIn(clientTokenOrTokenizationKey: self.addtoken)
            // As an example, you may wish to present Drop-in at this point.
            // Continue to the next section to learn more...
            }.resume()
    }
    func showDropIn(clientTokenOrTokenizationKey: String) {
        let request =  BTDropInRequest()
        let dropIn = BTDropInController(authorization: clientTokenOrTokenizationKey, request: request)
        { (controller, result, error) in
            if (error != nil) {
                print("ERROR")
            } else if (result?.isCancelled == true) {
                print("CANCELLED")
            } else if let result = result {
                print(result.paymentDescription)
                // Use the BTDropInResult properties to update your UI
                let selectedPaymentOptionType = result.paymentOptionType
                let selectedPaymentMethod = result.paymentMethod
                let selectedPaymentMethodIcon = result.paymentIcon
                let selectedPaymentMethodDescription = result.paymentDescription
                print(selectedPaymentMethodDescription)
            }
            controller.dismiss(animated: true, completion: nil)
            
            }
        self.present(dropIn!, animated: true, completion: nil)
//        self.presentedViewController
    }
    func drop(_ viewController: BTDropInViewController!, didSucceedWith paymentMethod: BTPaymentMethodNonce!) {
        
        print(paymentMethod.type)
        
        // Send payment method nonce to your server
        
        dismiss(animated: true, completion: nil)
        let alert = UIAlertController(title: "Alert", message: "Send payment method nonce to your server Sucessfully", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }

}

